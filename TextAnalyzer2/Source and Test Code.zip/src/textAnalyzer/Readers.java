package textAnalyzer;

public interface Readers 
{
	void readFile();
}
