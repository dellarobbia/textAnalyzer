package textAnalyzer;

public interface Analyzers 
{
	String analyze(String analyzeText);
}
